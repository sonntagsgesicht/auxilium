
.. module:: <name>
    :noindex:

-----------------
API Documentation
-----------------

.. toctree::
    :glob:

    ./api/modules.rst
