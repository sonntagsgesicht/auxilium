
.. module:: <name>

-----------------
API Documentation
-----------------

.. toctree::
    :glob:

    ./api/*
