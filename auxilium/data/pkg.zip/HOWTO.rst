

.. doctest::

    >>> import <pkg>


Write your tutorial here...