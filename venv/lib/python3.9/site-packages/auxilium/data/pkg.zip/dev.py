# -*- coding: utf-8 -*-


import os
import logging

pkg = __import__(os.getcwd().split(os.sep)[-1])

logging.basicConfig()


if True:
    print("Write your development test scripts here.")
